//
//  ContactViewController.swift
//  CoreDataDemo
//
//  Created by webwerks on 21/01/20.
//  Copyright © 2020 hitesh. All rights reserved.
//

import UIKit
import CoreData
enum type {
    case new
    case edit
    case delete
}
class ContactViewController: UIViewController {
    @IBOutlet weak var barButton: UIButton!
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var enailTextField: UITextField!
    var vcType:type = type.new
    var contact : NSManagedObject?
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        switch vcType {
        case .edit:
            barButton.setTitle("Update", for: UIControl.State.normal)
            initContact()
        case .new:
            barButton.setTitle("Save", for: UIControl.State.normal)
        case .delete:
            barButton.setTitle("Delete", for: UIControl.State.normal)
            initContact()
        }
    }
    func initContact(){
        guard let contact=contact else {
            return
        }
        self.enailTextField.text = contact.value(forKeyPath: "email") as? String
        self.nameTextField.text = contact.value(forKeyPath: "name") as? String
        self.phoneTextField.text = contact.value(forKeyPath: "phone") as? String
        if let imageData: Data =  contact.value(forKeyPath: "image") as? Data
        {
        let image = UIImage.init(data:imageData as Data)
        self.imageview.image = image
        }              
    }
    @IBAction func barButtonAction(_ sender: Any) {
        switch vcType {
        case .edit:
            editUser()
        case .new:
            saveUser()
        case .delete:
            deleteUser()
        }
    }
    func editUser()
    {
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
          return
        }
        let managedContext =
          appDelegate.persistentContainer.viewContext
        contact?.setValue(nameTextField.text, forKeyPath: "name")
        contact?.setValue(phoneTextField.text, forKeyPath: "phone")
        contact?.setValue(enailTextField.text, forKeyPath: "email")
        let imageData = imageview.image!.jpegData(compressionQuality: 1.0)
        contact?.setValue(imageData, forKeyPath: "image")
        do {
          try managedContext.save()
        } catch let error as NSError {
          print("Could not save. \(error), \(error.userInfo)")
        }
        self.navigationController?.popViewController(animated: true)
    }
    func saveUser()
    {
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
          return
        }
        let managedContext =
          appDelegate.persistentContainer.viewContext
        let entity =
          NSEntityDescription.entity(forEntityName: "Contact",
                                     in: managedContext)!
        contact = NSManagedObject(entity: entity,
                                  insertInto: managedContext) as! Contact
        contact?.setValue(nameTextField.text, forKeyPath: "name")
        contact?.setValue(phoneTextField.text, forKeyPath: "phone")
        contact?.setValue(enailTextField.text, forKeyPath: "email")
        contact?.setValue(enailTextField.text, forKeyPath: "address")
        let imageData = imageview.image!.jpegData(compressionQuality: 1.0)
        contact?.setValue(imageData, forKeyPath: "image")
        
    
        do {
          try managedContext.save()
        } catch let error as NSError {
          print("Could not save. \(error), \(error.userInfo)")
        }
        self.navigationController?.popViewController(animated: true)
    }
    func deleteUser()
    {
        guard let contact=contact else {
                   return
               }
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
          return
        }
        let managedContext =
          appDelegate.persistentContainer.viewContext
        managedContext.delete(contact)
        do {
          try managedContext.save()
        } catch let error as NSError {
          print("Could not save. \(error), \(error.userInfo)")
        }
        self.navigationController?.popViewController(animated: true)
    }
}
