//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by webwerks on 21/01/20.
//  Copyright © 2020 hitesh. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {
    var contactsArray: [NSManagedObject] = []
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidAppear(_ animated: Bool) {
        fetechContacts()
    }
    func fetechContacts() {
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext =
          appDelegate.persistentContainer.viewContext
        let fetchRequest =
          NSFetchRequest<NSManagedObject>(entityName: "Contact")
        do {
          contactsArray = try managedContext.fetch(fetchRequest)
            tableView.reloadData()
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
}
extension ViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        contactsArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let contact = contactsArray[indexPath.row]
        cell.textLabel?.text = contact.value(forKeyPath: "name") as? String
        var addres =  contact.value(forKeyPath: "address") as? String
        if let imageData: Data =  contact.value(forKeyPath: "image") as? Data
        {
        let image = UIImage.init(data:imageData as Data)
        cell.imageView?.image = image
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let contact = contactsArray[indexPath.row]
        let contactViewController:ContactViewController = self.storyboard?.instantiateViewController(withIdentifier: "ContactViewController") as! ContactViewController
        contactViewController.contact = contact
        contactViewController.vcType = .delete
        self.navigationController?.pushViewController(contactViewController, animated: true)
    }
}

