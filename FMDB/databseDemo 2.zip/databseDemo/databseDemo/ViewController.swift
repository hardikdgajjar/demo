//
//  ViewController.swift
//  databseDemo
//
//  Created by webwerks on 15/01/20.
//  Copyright © 2020 hitesh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let prayerarray =  DataBase().getPrayerstable() ?? [Prayers]()
        for prayer in prayerarray
        {

            print("*Id:\(prayer.prayerId ?? "") *topic:\(prayer.topic ?? "") *prayer:\(prayer.prayer ?? "")\n------")
        }
    }
    
}

