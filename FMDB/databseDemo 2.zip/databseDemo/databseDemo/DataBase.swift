
//
//  DataBase.swift
//  Tranzlease
//
//  Created by webwerks on 30/05/19.
//  Copyright © 2019 Tranzlease. All rights reserved.
//

import UIKit
import FMDB
class DataBase: NSObject {
    func getDatabse(fileName:String)->FMDatabase?
    {
        let dbFilePath = Bundle.main.path(forResource: fileName, ofType: "sqlite")
        let database = FMDatabase(url: URL.init(string: dbFilePath ?? ""))
        return database
    }
    // MARK: - get Prayers Table
    func getPrayerstable()->[Prayers]?
    {
        var prayersArray = [Prayers]()
        let database = getDatabse(fileName: "prayers")
        guard database!.open() else {
            print("Unable to open database")
            return prayersArray
        }
        do {
            let rs = try database!.executeQuery("select * from prayers", values: nil)
            while rs.next() {
                let dic:NSMutableDictionary =  ["prayerId" : rs.string(forColumn: "prayerId") ?? "",
                                                "topic" : rs.string(forColumn: "Topic") ?? "",
                                                "prayer" : rs.string(forColumn: "Prayer") ?? ""]
                let prayersObject : Prayers = Prayers(from: dic)
                prayersArray.append(prayersObject)
            }
        } catch {
            print("failed: \(error.localizedDescription)")
        }
        database!.close()
        return prayersArray
    }
}
