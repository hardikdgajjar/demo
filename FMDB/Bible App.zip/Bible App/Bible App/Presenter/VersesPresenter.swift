//
//  VersesPresenter.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import Foundation

protocol VersesDelegate: NSObjectProtocol {
    func didGetVersesFailed(error: ErrorObject)
    func didGetVerses(verses: [VersesModel])
}

class VersesPresenter {
    
    private let versesService: VersesService?
    weak var versesDelegate: VersesDelegate?
    
     init(VersesService: VersesService) {
        self.versesService = VersesService
    }
    
    func showDevotionVerses() {
        versesService?.getVerses(callBack: { (versesList, error) in
            if let error = error {
                self.versesDelegate?.didGetVersesFailed(error: error)
            } else {
                if let versesArray = versesList {
                    self.versesDelegate?.didGetVerses(verses: versesArray)
                }
            }
        })
    }
    
    
}

