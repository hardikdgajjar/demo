//
//  PrayersPresenter.swift
//  Bible App
//
//  Created by webwerks on 21/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import Foundation

protocol PrayersDelegate: NSObjectProtocol {
    
    func didGetPrayersFailed(error: ErrorObject)
    func didGetPrayers(prayers: [PrayersModel])
}

class PrayersPresenter {
    
    private let prayersService: PrayersService?
    weak var prayersDelegate: PrayersDelegate?
    
    init(prayersService: PrayersService) {
        self.prayersService = prayersService
    }
    
    func showDevotionPrayers() {
        prayersService?.getPrayers(callBack: { (prayerList, error) in
            if let error = error {
                self.prayersDelegate?.didGetPrayersFailed(error: error)
            } else {
                if let prayerArray = prayerList {
                    self.prayersDelegate?.didGetPrayers(prayers: prayerArray)
                }
            }
        })
    }
}
