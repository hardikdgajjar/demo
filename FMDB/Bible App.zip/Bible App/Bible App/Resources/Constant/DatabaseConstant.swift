//
//  DatabaseConstant.swift
//  Bible App
//
//  Created by webwerks on 20/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import Foundation

struct DatabaseConstant {
   
    //Prayer
    static let prayerId = "PrayerId"
    static let topic = "Topic"
    static let prayer = "Prayer"
    
    //Verses
    static let verseId = "VerseId"
    static let verse = "Verse"
    static let passage = "Passage"
    static let commentary = "Commentary"
    
    //Article
    static let button = "Button"
    static let title = "Title"
    static let titleDescription = "Title Description"
    static let itemOne = "Item 1"
    static let itemDescriptionOne = "Item 1 Description"
    static let itemTwo = "Item 2"
    static let itemDescriptionTwo = "Item 2 Description"
    static let itemThree = "Item 3"
    static let itemDescriptionThree = "Item 3 Description"
    static let itemFour = "Item 4"
    static let itemDescriptionFour = "Item 4 Description"
    static let itemFive = "Item 5"
    static let itemDescriptionFive = "Item 5 Description"
    static let itemSix = "Item 6"
    static let itemDescriptionSix = "Item 6 Description"
    static let itemSeven = "Item 7"
    static let itemDescriptionSeven = "Item 7 Description"
    static let itemEight = "Item 8"
    static let itemDescriptionEight = "Item 8 Description"
    static let itemNine = "Item 9"
    static let itemDescriptionNine = "Item 9 Description"
    static let itemTen = "Item 10"
    static let itemDescriptionTen = "Item 10 Description"
    static let itemEleven = "Item 11"
    static let itemDescriptionEleven = "Item 11 Description"
    
    //Trivia
    static let triviaId = "TriviaId"
    static let question = "Question"
    static let optionA = "Option_a"
    static let optionB = "Option_b"
    static let optionC = "Option_c"
    static let optionD = "Option_d"
    static let answer = "Answer"
    static let explanation = "Explanation"
}

