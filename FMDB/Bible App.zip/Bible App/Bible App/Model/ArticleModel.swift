//
//  ArticleModel.swift
//  Bible App
//
//  Created by webwerks on 21/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import Foundation

struct ArticleModel: Codable {
    let button: String
    let title: String
    let titleDescription: String
    let itemOne: String
    let itemDescriptionOne: String
    let itemTwo: String
    let itemDescriptionTwo: String
    let itemThree: String
    let itemDescriptionThree: String
    let itemFour: String
    let itemDescriptionFour: String
    let itemFive: String
    let itemDescriptionFive: String
    let itemSix: String
    let itemDescriptionSix: String
    let itemSeven: String
    let itemDescriptionSeven: String
    let itemEight: String
    let itemDescriptionEight: String
    let itemNine: String
    let itemDescriptionNine: String
    let itemTen: String
    let itemDescriptionTen: String
    let itemEleven: String
    let itemDescriptionEleven: String
    
    init(from dictionary: [String:String]) {
        button = dictionary[DatabaseConstant.button] ?? ""
        title = dictionary[DatabaseConstant.title] ?? ""
        titleDescription = dictionary[DatabaseConstant.titleDescription] ?? ""
        itemOne = dictionary[DatabaseConstant.itemOne] ?? ""
        itemDescriptionOne = dictionary[DatabaseConstant.itemDescriptionOne] ?? ""
        itemTwo = dictionary[DatabaseConstant.itemTwo] ?? ""
        itemDescriptionTwo = dictionary[DatabaseConstant.itemDescriptionTwo] ?? ""
        itemThree = dictionary[DatabaseConstant.itemThree] ?? ""
        itemDescriptionThree = dictionary[DatabaseConstant.itemDescriptionThree] ?? ""
        itemFour = dictionary[DatabaseConstant.itemFour] ?? ""
        itemDescriptionFour = dictionary[DatabaseConstant.itemDescriptionFour] ?? ""
        itemFive = dictionary[DatabaseConstant.itemFive] ?? ""
        itemDescriptionFive = dictionary[DatabaseConstant.itemDescriptionFive] ?? ""
        itemSix = dictionary[DatabaseConstant.itemSix] ?? ""
        itemDescriptionSix = dictionary[DatabaseConstant.itemDescriptionSix] ?? ""
        itemSeven = dictionary[DatabaseConstant.itemSeven] ?? ""
        
        itemDescriptionSeven = dictionary[DatabaseConstant.itemDescriptionSeven] ?? ""
        itemEight = dictionary[DatabaseConstant.itemEight] ?? ""
        itemDescriptionEight = dictionary[DatabaseConstant.itemDescriptionEight] ?? ""
        itemNine = dictionary[DatabaseConstant.itemNine] ?? ""
        itemDescriptionNine = dictionary[DatabaseConstant.itemDescriptionNine] ?? ""
        itemTen = dictionary[DatabaseConstant.itemTen] ?? ""
        itemDescriptionTen = dictionary[DatabaseConstant.itemDescriptionTen] ?? ""
        itemEleven = dictionary[DatabaseConstant.itemEleven] ?? ""
        itemDescriptionEleven = dictionary[DatabaseConstant.itemDescriptionEleven] ?? ""
    }
}
