//
//  VersesModel.swift
//  Bible App
//
//  Created by webwerks on 21/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import Foundation

struct VersesModel : Codable {
    let verseId : String
    let verse : String
    let passage : String
    let commentary : String
        
    init(from dictionary: [String:String]) {
        verseId = dictionary[DatabaseConstant.verseId] ?? ""
        verse = dictionary[DatabaseConstant.verse] ?? ""
        passage = dictionary[DatabaseConstant.passage] ?? ""
        commentary = dictionary[DatabaseConstant.commentary] ?? ""
    }
}
