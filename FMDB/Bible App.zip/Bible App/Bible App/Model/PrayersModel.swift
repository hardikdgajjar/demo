import Foundation

struct PrayersModel : Codable {
    let prayerId : String
    let topic : String
    let prayer : String
    
    init(from dictionary: [String:String]){
        prayerId = dictionary[DatabaseConstant.prayerId] ?? ""
        topic = dictionary[DatabaseConstant.topic] ?? ""
        prayer = dictionary[DatabaseConstant.prayer] ?? ""
    }
}
