//
//  AppDelegate.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        window?.makeKeyAndVisible()
        changeStatusBarColor()
        //getFontList()
        //UIBarButtonItem.appearance()
        //[[UIBarButtonItem appearance] setBackButtonBackgroundVerticalPositionAdjustment:-3 forBarMetrics:UIBarMetricsDefault];
        UIBarButtonItem.appearance().setBackButtonBackgroundVerticalPositionAdjustment(10, for: .default)
        return true
    }

}

extension AppDelegate {
    func changeStatusBarColor() {
        let statusBarView = UIView(frame: UIApplication.shared.statusBarFrame)
        
        statusBarView.backgroundColor = UIColor.appThemeColor
        UIApplication.shared.keyWindow?.addSubview(statusBarView)
    }
    
    func getFontList() {
        for family: String in UIFont.familyNames
        {
            print("\(family)")
            for names: String in UIFont.fontNames(forFamilyName: family)
            {
                   print("== \(names)")
            }
        }
    }
}

