//
//  Article.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit
import FMDB

class ArticleService {
    func getDevotion(callBack: (String?) -> Void) {
        callBack("Devotion")
    }
}
