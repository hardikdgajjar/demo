//
//  TriviaService.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit
import FMDB

class TriviaService {
    func getDevotion(callBack: (String?) -> Void) {
        callBack("Devotion")
    }
}
