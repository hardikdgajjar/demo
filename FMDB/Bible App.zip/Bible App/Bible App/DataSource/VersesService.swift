//
//  VersesService.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit
import FMDB

class VersesService {
    
    func getVerses(callBack:([VersesModel]?, ErrorObject?) -> Void) {
        var versesArray = [VersesModel]()
        let database = DataBaseService.getDatabse(fileName: "bible")
        
        guard database!.open() else {
            print("Unable to open database")
            callBack(versesArray, ErrorObject(errCode: 0, errMessage: "Unable to open database"))
            return
        }
        do {
           let result = try database!.executeQuery("select * from verses", values: nil)
            while result.next() {
                let dict:[String:String] =  [DatabaseConstant.verseId: result.string(forColumn: DatabaseConstant.verseId) ?? "",
                                             DatabaseConstant.verse: result.string(forColumn: DatabaseConstant.verse) ?? "",
                                             DatabaseConstant.passage: result.string(forColumn: DatabaseConstant.passage) ?? "",
                                             DatabaseConstant.commentary: result.string(forColumn: DatabaseConstant.commentary) ?? ""]
                
                let versesObject = VersesModel(from: dict)
                versesArray.append(versesObject)
            }
        } catch {
            print("failed: \(error.localizedDescription)")
            callBack(versesArray, ErrorObject(errCode: 0, errMessage: error.localizedDescription))
        }
        database!.close()
        callBack(versesArray,nil)
    }
    
    //    func getVerses() -> [VersesModel] {
    //        var versesArray = [VersesModel]()
    //        let database = DataBaseService.getDatabse(fileName: "bible")
    //
    //        guard database!.open() else {
    //            print("Unable to open database")
    //            return versesArray
    //        }
    //        do {
    //            let result = try database!.executeQuery("select * from verses", values: nil)
    //            while result.next() {
    //                let dict:[String:String] =  [DatabaseConstant.verseId: result.string(forColumn: DatabaseConstant.verseId) ?? "",
    //                                             DatabaseConstant.verse: result.string(forColumn: DatabaseConstant.verse) ?? "",
    //                                             DatabaseConstant.passage: result.string(forColumn: DatabaseConstant.passage) ?? "",
    //                                             DatabaseConstant.commentary: result.string(forColumn: DatabaseConstant.commentary) ?? ""]
    //
    //                let versesObject = VersesModel(from: dict)
    //                versesArray.append(versesObject)
    //            }
    //        } catch {
    //            print("failed: \(error.localizedDescription)")
    //        }
    //        database!.close()
    //        return versesArray
    //    }
}
