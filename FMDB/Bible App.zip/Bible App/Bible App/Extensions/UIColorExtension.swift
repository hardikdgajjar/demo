//
//  UIColorExtension.swift
//  Bible App
//
//  Created by webwerks on 15/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class UIColorExtension: UIColor {

}

extension UIColor {
    
    static let appThemeColor = UIColor.systemOrange//UIColor(red: 210.@objc 0/255.0, green: 105.0/255.0, blue: 130.0/255.0, alpha: 1.0)
    
}
