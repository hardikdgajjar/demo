//
//  UIViewControllerExtension.swift
//  Bible App
//
//  Created by webwerks on 16/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit
import DropDown
import SafariServices

extension UIViewController: SFSafariViewControllerDelegate {
    
    func addRightMenuButton(imageName:String) {
        let menuButton = UIButton(type: .custom)
        menuButton.setImage(UIImage(named: imageName), for: .normal)
        menuButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        let barButton = UIBarButtonItem(customView: menuButton)
        let spacer = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.fixedSpace, target: nil, action: nil)
        spacer.width = -15
        self.navigationItem.rightBarButtonItems = [spacer,barButton]
        menuButton.addTarget(self, action: #selector(menuButtonButtonAction(menutbutton:)), for: .touchUpInside)
    }
    
    @objc func menuButtonButtonAction(menutbutton:UIButton) {
        let dropDown = DropDown()
        dropDown.anchorView = menutbutton
        dropDown.textFont = UIFont.appRegularFontWith(size: 16.0)
        if let pagerVC = self as? PagerViewController {
            if (pagerVC.viewControllers.first as? FavoriteVersesViewController) != nil  {
                dropDown.dataSource = ["Rate Us!", "Settings", "Our Terms of Service", "Our Privacy policy"]
            } else {
                dropDown.dataSource = ["My Favorites", "Rate Us!", "Settings", "Our Terms of Service", "Our Privacy policy"]
            }
        } else {
            dropDown.dataSource = ["My Favorites", "Rate Us!", "Settings", "Our Terms of Service", "Our Privacy policy"]
        }
        
        // Action triggered on selection
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            dropDown.hide()
            self.selectedMenu(index: index)
            switch item {
            case "My Favorites":
                if let pagerVC = self.storyboard!.instantiateViewController(withIdentifier: String(describing: PagerViewController.self)) as? PagerViewController {
                    pagerVC.screenType = .favorite
                    self.navigationController?.pushViewController(pagerVC, animated: true)
                }
            case "Rate Us!":
                print("Rate us")
                self.rateApp(appId: "id1147613120")
                
            case "Settings":
                print("Settings")
                if let settingVC = self.storyboard!.instantiateViewController(withIdentifier: String(describing: SettingsViewController.self)) as? SettingsViewController {
                    
                    self.navigationController?.pushViewController(settingVC, animated: true)
                }
            case "Our Terms of Service":
                print("Service")
                if let url = URL(string: "http://cameetapp.com/tos.html")
                {
                    let safariVC = SFSafariViewController(url: url)
                    self.present(safariVC, animated: true, completion: nil)
                    safariVC.delegate = self
                }
            case "Our Privacy policy":
                print("Service")
                if let url = URL(string: "http://cameetapp.com/tos.html")
                {
                    let safariVC = SFSafariViewController(url: url)
                    self.present(safariVC, animated: true, completion: nil)
                    safariVC.delegate = self
                }
            default:
                print("")
            }
            
        }
        dropDown.show()
    }
    
    @objc func selectedMenu(index:Int) {
        print("index \(index)")
    }
    
    public func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    fileprivate func rateApp(appId: String) {
        openUrl("https://apps.apple.com/in/app/knowdiabetes/" + appId)
    }
    
    fileprivate func openUrl(_ urlString:String) {
        let url = URL(string: urlString)!
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
}
