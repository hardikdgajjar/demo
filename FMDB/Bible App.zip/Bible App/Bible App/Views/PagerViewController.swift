//
//  PagerViewController.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit
import DTPagerController
import DropDown

enum ScreenType: Int {
   case devotion = 0
   case trivia
   case favorite
   case none = -1
}

class PagerViewController: DTPagerController {
    
    var screenType = ScreenType(rawValue: -1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Bible App"
        // Do any additional setup after loading the view.
        self.addRightMenuButton(imageName: "open-menu")
        segmentSetUp()
    }
}

extension PagerViewController {
    
    /// MARK: - HelperMethod
    func segmentSetUp() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        switch screenType {
        case .devotion, .trivia:
            if let devotionVC = storyboard.instantiateViewController(withIdentifier: "DevotionViewController") as? DevotionViewController,
                let playTriviaVC = storyboard.instantiateViewController(withIdentifier: "PlayTriviaViewController") as? PlayTriviaViewController {
                
                devotionVC.title = "Afternoon Devotion"
                playTriviaVC.title = "Trivia"
                
                viewControllers = [devotionVC, playTriviaVC]
                setSelectedPageIndex(screenType?.rawValue ?? 0, animated: false)
            }
        default:
            
            if let favVerseVC = storyboard.instantiateViewController(withIdentifier: String(describing: FavoriteVersesViewController.self)) as? FavoriteVersesViewController,
                let favPrayerVC = storyboard.instantiateViewController(withIdentifier: String(describing: FavoritePrayersViewController.self)) as? FavoritePrayersViewController {
                
                favVerseVC.title = "Favorite Verses"
                favPrayerVC.title = "Favorite Prayers"
                
                viewControllers = [favVerseVC, favPrayerVC]
                setSelectedPageIndex(0, animated: false)
            }
        }
        
        scrollIndicator.backgroundColor = UIColor.appThemeColor
        //.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)
        
        pageSegmentedControl.setTitleTextAttributes([.foregroundColor: UIColor.appThemeColor, .font: UIFont.appBoldFontWith(size: 15.0)], for: .selected)
        pageSegmentedControl.setTitleTextAttributes([.foregroundColor: UIColor.lightGray, .font: UIFont.appBoldFontWith(size: 15.0)], for: .normal)
        ///pageSegmentedControl.setTitleTextAttributes([.foregroundColor: UIColor.orange], for: .normal)
        
        if #available(iOS 13.0, *) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                for i in 0...1  {
                    let backgroundSegmentView = self.pageSegmentedControl.subviews[i]
                    
                    ///it is not enogh changing the background color. But use for white background.
                    backgroundSegmentView.isHidden = true
                }
            }
            
        } else {
            pageSegmentedControl.backgroundColor = .white
        }
        
        
    }
}
