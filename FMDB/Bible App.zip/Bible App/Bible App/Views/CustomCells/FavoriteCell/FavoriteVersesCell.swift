//
//  FavoriteVersesCell.swift
//  Bible App
//
//  Created by webwerks on 16/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class FavoriteVersesCell: UICollectionViewCell {

    @IBOutlet weak var verseLabel: UILabel!
    @IBOutlet weak var passageLabel: UILabel!
    @IBOutlet weak var commentaryLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        passageLabel.setLineSpacing(lineSpacing: 3.0)
        commentaryLabel.setLineSpacing(lineSpacing: 3.0)
    }

}
