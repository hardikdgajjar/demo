//
//  FavoritePrayerCell.swift
//  Bible App
//
//  Created by webwerks on 16/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class FavoritePrayerCell: UICollectionViewCell {
    
    @IBOutlet weak var prayerLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        prayerLabel.setLineSpacing(lineSpacing: 3.0)
        
    }

}
