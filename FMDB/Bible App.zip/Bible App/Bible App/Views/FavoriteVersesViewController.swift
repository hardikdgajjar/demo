//
//  FavoriteViewController.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class FavoriteVersesViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.register(UINib(nibName: String(describing: FavoriteVersesCell.self), bundle: nil), forCellWithReuseIdentifier: String(describing: FavoriteVersesCell.self))
    }
    

    // MARK: - IBAction
    
    @IBAction func previousButtonTapped(_ sender: UIButton) {
        
    }
    
    @IBAction func favoriteUnfavourButtonTapped(_ sender: UIButton) {
        
        if sender.tag == 0 {
            sender.setImage(UIImage(named: "heart_red"), for: .normal)
            sender.setTitleColor(.systemRed, for: .normal)
            sender.tag = 1
        } else {
            sender.setImage(UIImage(named: "Heart_unfill"), for: .normal)
            sender.setTitleColor(.darkGray, for: .normal)
            sender.tag = 0
        }
    }
    
    @IBAction func nextButtonTapped(_ sender: UIButton) {
        
    }

}


extension FavoriteVersesViewController: UICollectionViewDataSource,UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: FavoriteVersesCell.self), for: indexPath) as? FavoriteVersesCell else {
            return UICollectionViewCell()
        }

//        }else {
//            cell.titleLabel.text = "Ballard Estate"
//        }
        return cell
    }
    
    
    
}

extension FavoriteVersesViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: collectionView.frame.width  - 10, height: collectionView.frame.height)
    }
}
