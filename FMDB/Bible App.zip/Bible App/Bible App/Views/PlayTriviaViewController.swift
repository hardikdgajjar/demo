//
//  PlayTriviaViewController.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class PlayTriviaViewController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    var isAnswer = Bool()

    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.register(UINib(nibName: String(describing: TriviaQuestionCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TriviaQuestionCell.self))
        tableview.register(UINib(nibName: String(describing: TriviaOptionsCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TriviaOptionsCell.self))
        tableview.register(UINib(nibName: String(describing: TriviaQuestionAdsCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TriviaQuestionAdsCell.self))
        tableview.register(UINib(nibName: String(describing: AnswerStatusCell.self), bundle: nil), forCellReuseIdentifier: String(describing: AnswerStatusCell.self))
        //tableview.register(UINib(nibName: String(describing: TriviaQuestionAdsCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TriviaQuestionAdsCell.self))
        tableview.tableFooterView = UIView()
    }
    

    @objc func optionButtonTapped(_ sender: UIButton) {
        isAnswer = true
        tableview.reloadData()
    }
    
    @objc func nextQuestionButtonTapped(_ sender: UIButton) {
        
        isAnswer = false
        tableview.reloadData()
    }

}

extension PlayTriviaViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (isAnswer ? 1 : 2)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if isAnswer {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: AnswerStatusCell.self), for: indexPath) as?
                AnswerStatusCell else { return UITableViewCell() }
            
            cell.buttonNextQuestion.addTarget(self, action: #selector(nextQuestionButtonTapped(_:)), for: .touchUpInside)
            
            cell.labelAnswerDetail.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there. All you have to do is making your custom UIControl conform DTSegmentedControlProtocol. For example, as shown in sample project, HMSegmentedControl is made to conform DTSegmentedControlProtocol by using extension."
            
            return cell
            
        } else {
            switch indexPath.row {
            case 0:
                guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: TriviaQuestionCell.self), for: indexPath) as?
                    TriviaQuestionCell else { return UITableViewCell() }
                //cell.labelDetail.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there. All you have to do is making your custom UIControl conform DTSegmentedControlProtocol. For example, as shown in sample project, HMSegmentedControl is made to conform DTSegmentedControlProtocol by using extension."
                
                return cell
            case 1:
                guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: TriviaOptionsCell.self), for: indexPath) as?
                    TriviaOptionsCell else { return UITableViewCell() }
                
                cell.buttonOpt1.addTarget(self, action: #selector(optionButtonTapped(_:)), for: .touchUpInside)
                cell.buttonOpt2.addTarget(self, action: #selector(optionButtonTapped(_:)), for: .touchUpInside)
                cell.buttonOpt3.addTarget(self, action: #selector(optionButtonTapped(_:)), for: .touchUpInside)
                cell.buttonOpt4.addTarget(self, action: #selector(optionButtonTapped(_:)), for: .touchUpInside)
                
                return cell
                
            default:
                return UITableViewCell()
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
}
