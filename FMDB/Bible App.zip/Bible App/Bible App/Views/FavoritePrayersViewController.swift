//
//  FavoritePrayersViewController.swift
//  Bible App
//
//  Created by webwerks on 16/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class FavoritePrayersViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.register(UINib(nibName: String(describing: FavoritePrayerCell.self), bundle: nil), forCellWithReuseIdentifier: String(describing: FavoritePrayerCell.self))
    }
    
    
    // MARK: - IBAction
    
    @IBAction func previousButtonTapped(_ sender: UIButton) {
        
    }
    
    @IBAction func favoriteUnfavourButtonTapped(_ sender: UIButton) {
        
    }
    
    @IBAction func nextButtonTapped(_ sender: UIButton) {
        
    }
    
}


extension FavoritePrayersViewController: UICollectionViewDataSource,UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: FavoritePrayerCell.self), for: indexPath) as? FavoritePrayerCell else {
            return UICollectionViewCell()
        }
        
        //        }else {
        //            cell.titleLabel.text = "Ballard Estate"
        //        }
        return cell
    }
    
}

extension FavoritePrayersViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: collectionView.frame.width - 10, height: collectionView.frame.height)
    }
}
