//
//  DevotionViewController.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit
import DropDown

class DevotionViewController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    // MARK :- Variables
    private let versesPresenter = VersesPresenter(VersesService: VersesService())
    private let prayersPresenter = PrayersPresenter(prayersService: PrayersService())
    
   // private let presenter: VersesPresenter = LoginPresenter()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        versesPresenter.versesDelegate = self
        versesPresenter.showDevotionVerses()
        //VersesPresenter.showDevotionPresent()
        tableview.register(UINib(nibName: String(describing: DevotionCell.self), bundle: nil), forCellReuseIdentifier: String(describing: DevotionCell.self))
        tableview.register(UINib(nibName: "DevotionPrayerCell", bundle: nil), forCellReuseIdentifier: "DevotionPrayerCell")
        tableview.register(UINib(nibName: String(describing: DevotionArticleCell.self), bundle: nil), forCellReuseIdentifier: String(describing: DevotionArticleCell.self))
        tableview.register(UINib(nibName: String(describing: NativeAdsCell.self), bundle: nil), forCellReuseIdentifier: String(describing: NativeAdsCell.self))
        tableview.tableFooterView = UIView()
    }
    
    @objc func favoriteVerseButtonTapped(_ sender: UIButton) {
        if sender.tag == 0 {
            sender.setImage(UIImage(named: "heart_red"), for: .normal)
            sender.tag = 1
        } else {
        sender.setImage(UIImage(named: "Heart_unfill"), for: .normal)
            sender.tag = 0
        }
    }
    
    @objc func favoritePrayerButtonTapped(_ sender: UIButton) {
        if sender.tag == 0 {
            sender.setImage(UIImage(named: "heart_red"), for: .normal)
            sender.tag = 1
        } else {
        sender.setImage(UIImage(named: "Heart_unfill"), for: .normal)
            sender.tag = 0
        }
    }
    
    @objc func clickHereButtonTapped(_ sender: UIButton) {
        if let articleVC = self.storyboard!.instantiateViewController(withIdentifier: String(describing: ArticleViewController.self)) as? ArticleViewController {
            self.navigationController?.pushViewController(articleVC, animated: true)
        }
        
    }
}

extension DevotionViewController: VersesDelegate {
    
    func didGetVerses(verses: [VersesModel]) {
        for verse in verses {
            
            print("*Id:\(verse.verseId ) *verse:\(verse.verse ) *Passage:\(verse.passage) *Commentary:\(verse.commentary)\n------")
        }
    }
    
    func didGetVersesFailed(error: ErrorObject) {
        print("Error:\(error.errorMessage)")
    }
    
}

extension DevotionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.row {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: DevotionCell.self), for: indexPath) as?
                DevotionCell else { return UITableViewCell() }
            
            cell.labelPassage.text = "\"From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there.\""
            cell.labelCommentary.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there."
            cell.buttonFavoriteUnfavorite.addTarget(self, action: #selector(favoriteVerseButtonTapped(_:)), for: .touchUpInside)
            //cell.buttonFavoriteUnfavorite
            cell.selectionStyle = .none
            
            return cell
            case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "DevotionPrayerCell", for: indexPath) as?
                DevotionPrayerCell else { return UITableViewCell() }
            
            cell.labelPrayer.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there."
            
            cell.buttonFavoriteUnfavorite.addTarget(self, action: #selector(favoritePrayerButtonTapped(_:)), for: .touchUpInside)
            
            cell.selectionStyle = .none
            
            return cell
        case 2,3:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: DevotionArticleCell.self), for: indexPath) as?
                DevotionArticleCell else { return UITableViewCell() }
            
            cell.labelDetail.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there."
            cell.buttonClickHere.addTarget(self, action: #selector(clickHereButtonTapped(_:)), for: .touchUpInside)
            
            cell.selectionStyle = .none
            
            return cell
            
            case 4:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: NativeAdsCell.self), for: indexPath) as?
                NativeAdsCell else { return UITableViewCell() }
 
            cell.selectionStyle = .none
            
            return cell
        default:
            return UITableViewCell()
        }
       
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
}


