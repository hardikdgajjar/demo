//
//  ArticleViewController.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class ArticleViewController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.addRightMenuButton(imageName: "open-menu")
        
        tableview.register(UINib(nibName: String(describing: ArticleTipsCell.self), bundle: nil), forCellReuseIdentifier: String(describing: ArticleTipsCell.self))
        tableview.register(UINib(nibName: String(describing: ArticlePointCell.self), bundle: nil), forCellReuseIdentifier: String(describing: ArticlePointCell.self))
        tableview.register(UINib(nibName: String(describing: ArticleNextCell.self), bundle: nil), forCellReuseIdentifier: String(describing: ArticleNextCell.self))
        tableview.register(UINib(nibName: String(describing: NativeAdsCell.self), bundle: nil), forCellReuseIdentifier: String(describing: NativeAdsCell.self))

        tableview.tableFooterView = UIView()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ArticleViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.row {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ArticleTipsCell.self), for: indexPath) as?
                ArticleTipsCell else { return UITableViewCell() }
            
            //        cell.ArticleTipsCell.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there. All you have to do is making your custom UIControl conform DTSegmentedControlProtocol. For example, as shown in sample project, HMSegmentedControl is made to conform DTSegmentedControlProtocol by using extension."
            //cell.selectionStyle = .none
            
            return cell
        case 1,2:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ArticlePointCell.self), for: indexPath) as?
                ArticlePointCell else { return UITableViewCell() }
            
            cell.labelPointDetail.text = "From version 2.0.0, DTPagerController supports custom segmented control. Therefore, instead of using default DTSegmentedControl, you can provide your own segmented control or any 3rd-party segmented control libraries available out there. All you have to do is making your custom UIControl conform DTSegmentedControlProtocol. For example, as shown in sample project, HMSegmentedControl is made to conform DTSegmentedControlProtocol by using extension."
            //cell.selectionStyle = .none
            
            return cell
            case 3:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ArticleNextCell.self), for: indexPath) as?
                ArticleNextCell else { return UITableViewCell() }
            
            //cell.selectionStyle = .none
            
            return cell
            case 4:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: NativeAdsCell.self), for: indexPath) as?
                NativeAdsCell else { return UITableViewCell() }
            
            //cell.selectionStyle = .none
            
            return cell
        default:
            return UITableViewCell()
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
}


