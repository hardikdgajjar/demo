//
//  HomeViewController.swift
//  Bible App
//
//  Created by webwerks on 14/01/20.
//  Copyright © 2020 webwerks. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    private let prayersPresenter = PrayersPresenter(prayersService: PrayersService())

    override func viewDidLoad() {
        super.viewDidLoad()
        //refreshStatusBar()
        self.addRightMenuButton(imageName: "open-menu")
        prayersPresenter.prayersDelegate = self
        prayersPresenter.showDevotionPrayers()
    }
    
    // MARK: - IBAction
    
    @IBAction func afternoonDevotionButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: String(describing: PagerViewController.self), sender: sender.tag)
    }
    
    @IBAction func articleButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: String(describing: ArticleViewController.self), sender: nil)
    }
    
    @IBAction func playTrivia(_ sender: UIButton) {
        performSegue(withIdentifier: String(describing: PagerViewController.self), sender: sender.tag)
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == String(describing: PagerViewController.self) {
            if let devotionPagerVC = segue.destination as? PagerViewController,
                let index = sender as? Int {
                switch index {
                case 0:
                    devotionPagerVC.screenType = .devotion
                case 1:
                    devotionPagerVC.screenType = .trivia
                default:
                    devotionPagerVC.screenType = .trivia
                }
                
            }
        }
    }
    

}

extension HomeViewController {
    
    func refreshStatusBar() {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        
        appDelegate?.changeStatusBarColor()
        appDelegate?.window?.makeKeyAndVisible()
    }
}

extension HomeViewController: PrayersDelegate {
    func didGetPrayersFailed(error: ErrorObject) {
        print("Error:\(error.errorMessage)")
    }
    
    func didGetPrayers(prayers: [PrayersModel]) {
        for prayer in prayers {

            print("*Id:\(prayer.prayerId) *topic:\(prayer.topic) *prayer:\(prayer.prayer)\n------")
        }
    }
    

    
}
