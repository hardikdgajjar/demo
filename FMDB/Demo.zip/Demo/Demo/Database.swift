//
//  Database.swift
//  Demo
//
//  Created by Webwerks1 on 21/01/20.
//  Copyright © 2020 Webwerks1. All rights reserved.
//

import Foundation


class Database{
    
    
}
