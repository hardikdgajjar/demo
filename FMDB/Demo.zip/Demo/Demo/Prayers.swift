import Foundation
struct Prayers : Codable {
	let prayerId : String?
	let topic : String?
	let prayer : String?
    init(from dictionary: NSMutableDictionary){
        prayerId = dictionary.value(forKey: "prayerId") as? String
        topic = dictionary.value(forKey: "topic") as? String
        prayer = dictionary.value(forKey: "prayer") as? String
    }
}
